package entities;

public interface connecter {

}
